# HTML para APK

App Android que converte HTML (colado, um arquivo `.html` ou um site em `.zip`) em um APK instalável,
**tudo dentro do celular**, sem Gradle e sem servidor.

Escrito do zero. Não reaproveita código nem assets de nenhum app existente.

## Como funciona

```
shell/    app mínimo (WebView) que mostra o site de assets/www/. Vira o "molde" de todo APK gerado.
builder/  o app que você usa. Embute o APK do shell e, a cada build:
            1. troca nome, pacote e versão no AndroidManifest binário
            2. grava o site em assets/www/ e as opções em assets/config.json
            3. troca o ícone
            4. reempacota o ZIP (resources.arsc sem compressão, alinhado a 4 bytes)
            5. assina (v1+v2+v3) com uma chave por pacote e verifica a assinatura
```

Peças principais:

| Arquivo | O que faz |
|---|---|
| `builder/.../build/AxmlPatcher.java` | Edita o manifesto binário (string pool + `versionCode`) sem descompilar |
| `builder/.../build/ApkRepacker.java` | Reescreve o APK entrada a entrada, com alinhamento |
| `builder/.../build/ApkBuilder.kt` | Orquestra o pipeline e valida as entradas |
| `builder/.../build/KeyStoreProvider.kt` | Gera e guarda a chave/certificado por pacote |
| `shell/.../MainActivity.kt` | WebView servido por `https://appassets.androidplatform.net/` |

O pacote e o nome do app no shell são **placeholders** (`com.example.placeholder.app`, `__APP_NAME__`,
`0.0.0-placeholder`). Se mudar um, mude também as constantes em `ApkBuilder.kt`.

## Como compilar

1. Abra a pasta no Android Studio (JDK 17, SDK 36). Ele baixa o Gradle 8.13 sozinho
   (ou rode `gradle wrapper --gradle-version 8.13` para gerar o `gradlew`).
2. Rode o módulo `builder`. A tarefa `copyShellApk` compila o `shell` (release, sem assinatura)
   e o embute no builder automaticamente.

Linha de comando: `./gradlew :builder:assembleDebug`

## O que foi testado e o que não foi

Testado de verdade (JDK 21, contra um manifesto e um APK reais compilados pelo aapt2):

- `AxmlPatcher`: pool UTF-16 e UTF-8, nomes com acento, pacote maior que o original, `versionCode`.
  O resultado foi comparado com um parser independente: só mudou o que devia mudar.
- `ApkRepacker`: o ZIP abre, `resources.arsc` fica STORED com dados alinhados a 4 bytes, as demais
  entradas ficam idênticas.

**Não compilado nem executado:** o código Kotlin, o Gradle, a assinatura (apksig) e a UI.
Não havia Android SDK nem rede no ambiente em que isto foi escrito. Espere corrigir um ou outro erro
de compilação ou de versão de dependência na primeira sincronização.

## Pontos a verificar no primeiro build

- Instale um APK gerado e confirme que abre. O pacote é trocado só no manifesto; o `resources.arsc`
  continua com o nome de pacote do shell (o Android tolera isso).
- Gere dois apps com pacotes diferentes e instale os dois: serve para confirmar que não há conflito
  de `authorities` ou permissões.

## Limitações conhecidas

- **Chaves sem backup e sem senha**, em `filesDir/keys/`. Se desinstalar o builder, perde as chaves e
  não consegue mais atualizar apps já instalados. Para publicar na Play Store, adicione exportação de chave.
- O site inteiro fica em memória durante o build (limite de 64 MB).
- O shell não expõe ponte JavaScript↔nativo, e só pede permissão de INTERNET. Câmera, microfone, GPS,
  notificações e downloads exigem alterar o shell e o manifesto.
- Links externos (`http(s)`, `mailto`, `tel`) abrem fora do app. Tráfego HTTP sem TLS fica bloqueado
  (padrão do Android).
- Gera APK, não AAB.
