plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.htmltoapk.builder"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.htmltoapk.builder"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    sourceSets {
        getByName("main") {
            // 1) APK do shell, copiado pela tarefa abaixo
            // 2) ic_launcher.png do shell, usado como "ícone-placeholder" a ser substituído
            assets.srcDir(layout.buildDirectory.dir("generated/shell-assets"))
            assets.srcDir(rootProject.file("shell/src/main/res/mipmap-xxxhdpi"))
        }
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/INDEX.LIST",
                "META-INF/versions/**",
                "META-INF/*.kotlin_module",
            )
        }
    }
}

// Compila o shell (release, sem assinatura) e o embute como assets/shell-template.apk.
val copyShellApk = tasks.register<Copy>("copyShellApk") {
    dependsOn(":shell:assembleRelease")
    from(project(":shell").layout.buildDirectory.dir("outputs/apk/release")) {
        include("*.apk")
        rename { "shell-template.apk" }
    }
    into(layout.buildDirectory.dir("generated/shell-assets"))
}
tasks.matching { it.name.matches(Regex("merge.*Assets")) }.configureEach {
    dependsOn(copyShellApk)
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Assinatura v1/v2/v3 do APK (mesma biblioteca usada pelo Android Gradle Plugin)
    implementation("com.android.tools.build:apksig:8.13.2")
    // Geração do certificado autoassinado
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
}
