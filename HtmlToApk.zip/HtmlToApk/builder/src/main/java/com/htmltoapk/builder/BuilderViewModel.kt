package com.htmltoapk.builder

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.htmltoapk.builder.build.ApkBuilder
import com.htmltoapk.builder.build.BuildRequest
import com.htmltoapk.builder.build.IconProcessor
import com.htmltoapk.builder.build.ScreenOrientation
import com.htmltoapk.builder.build.ShellOptions
import com.htmltoapk.builder.build.SiteContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.Normalizer

enum class SourceMode(val label: String) { CODE("Colar código"), FILE("Arquivo .html"), ZIP("Site (.zip)") }

data class UiState(
    val appName: String = "",
    val packageName: String = "com.htmlapp.meuapp",
    val packageEdited: Boolean = false,
    val versionName: String = "1.0",
    val versionCode: String = "1",
    val mode: SourceMode = SourceMode.CODE,
    val htmlCode: String = SAMPLE_HTML,
    val sourceUri: Uri? = null,
    val sourceLabel: String? = null,
    val iconUri: Uri? = null,
    val iconPreview: Bitmap? = null,
    val options: ShellOptions = ShellOptions(),
    val building: Boolean = false,
    val log: List<String> = emptyList(),
    val result: File? = null,
    val error: String? = null,
)

class BuilderViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    fun setAppName(v: String) = _state.update {
        it.copy(appName = v, packageName = if (it.packageEdited) it.packageName else suggestPackage(v))
    }

    fun setPackage(v: String) = _state.update { it.copy(packageName = v.trim(), packageEdited = true) }
    fun setVersionName(v: String) = _state.update { it.copy(versionName = v) }
    fun setVersionCode(v: String) = _state.update { it.copy(versionCode = v.filter(Char::isDigit).take(10)) }
    fun setMode(m: SourceMode) = _state.update { it.copy(mode = m) }
    fun setHtmlCode(v: String) = _state.update { it.copy(htmlCode = v) }
    fun setOptions(o: ShellOptions) = _state.update { it.copy(options = o) }

    fun setSource(uri: Uri) {
        _state.update { it.copy(sourceUri = uri, sourceLabel = displayName(uri)) }
    }

    fun setIcon(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val png = IconProcessor.toLauncherPng(getApplication(), uri)
                    BitmapFactory.decodeByteArray(png, 0, png.size)
                }
            }.onSuccess { bmp -> _state.update { it.copy(iconUri = uri, iconPreview = bmp, error = null) } }
                .onFailure { e -> _state.update { it.copy(error = e.message ?: "Falha ao ler o ícone.") } }
        }
    }

    fun clearIcon() = _state.update { it.copy(iconUri = null, iconPreview = null) }

    fun build() {
        val s = _state.value
        if (s.building) return
        _state.update { it.copy(building = true, log = emptyList(), result = null, error = null) }
        viewModelScope.launch {
            val outcome = runCatching {
                withContext(Dispatchers.IO) {
                    val ctx = getApplication<Application>()
                    val site = when (s.mode) {
                        SourceMode.CODE -> {
                            require(s.htmlCode.isNotBlank()) { "Cole algum HTML." }
                            SiteContent.fromHtml(s.htmlCode.toByteArray())
                        }
                        SourceMode.FILE -> {
                            val uri = requireNotNull(s.sourceUri) { "Escolha um arquivo .html." }
                            val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                            SiteContent.fromHtml(bytes)
                        }
                        SourceMode.ZIP -> {
                            val uri = requireNotNull(s.sourceUri) { "Escolha um arquivo .zip." }
                            ctx.contentResolver.openInputStream(uri)!!.use { SiteContent.fromZip(it) }
                        }
                    }
                    val icon = s.iconUri?.let { IconProcessor.toLauncherPng(ctx, it) }
                    val request = BuildRequest(
                        appName = s.appName.trim(),
                        packageName = s.packageName.trim(),
                        versionName = s.versionName.trim(),
                        versionCode = s.versionCode.toIntOrNull() ?: 0,
                        site = site,
                        iconPng = icon,
                        options = s.options,
                    )
                    ApkBuilder(ctx).build(request) { line -> _state.update { it.copy(log = it.log + line) } }
                }
            }
            outcome
                .onSuccess { file -> _state.update { it.copy(building = false, result = file) } }
                .onFailure { e -> _state.update { it.copy(building = false, error = e.message ?: e.toString()) } }
        }
    }

    private fun displayName(uri: Uri): String? =
        getApplication<Application>().contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        } ?: uri.lastPathSegment

    private fun suggestPackage(name: String): String {
        val ascii = Normalizer.normalize(name, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        var slug = ascii.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }
        if (slug.isEmpty() || slug.first().isDigit()) slug = "app$slug"
        return "com.htmlapp.$slug"
    }
}

private const val SAMPLE_HTML = """<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Meu app</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 0; min-height: 100vh; display: grid;
           place-items: center; background: #1a237e; color: #fff; text-align: center; }
    button { font-size: 1.1rem; padding: .7rem 1.4rem; border: 0; border-radius: 999px; }
  </style>
</head>
<body>
  <main>
    <h1>Olá, mundo!</h1>
    <p id="n">Toques: 0</p>
    <button onclick="n.textContent='Toques: '+(++c)">Tocar</button>
  </main>
  <script>let c = 0;</script>
</body>
</html>
"""
