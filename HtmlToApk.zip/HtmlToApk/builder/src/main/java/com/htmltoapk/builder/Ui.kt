package com.htmltoapk.builder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.htmltoapk.builder.build.ScreenOrientation
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuilderApp(vm: BuilderViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setSource(uri)
    }
    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setIcon(uri)
    }

    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("HTML para APK") }) }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Section("Aplicativo") {
                OutlinedTextField(
                    value = s.appName, onValueChange = vm::setAppName, singleLine = true,
                    label = { Text("Nome do app") }, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = s.packageName, onValueChange = vm::setPackage, singleLine = true,
                    label = { Text("Pacote (ID único do app)") }, modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = s.versionName, onValueChange = vm::setVersionName, singleLine = true,
                        label = { Text("Versão") }, modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = s.versionCode, onValueChange = vm::setVersionCode, singleLine = true,
                        label = { Text("Código") }, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                }
            }

            Section("Conteúdo") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SourceMode.entries.forEach { mode ->
                        FilterChip(
                            selected = s.mode == mode, onClick = { vm.setMode(mode) },
                            label = { Text(mode.label) },
                        )
                    }
                }
                when (s.mode) {
                    SourceMode.CODE -> OutlinedTextField(
                        value = s.htmlCode, onValueChange = vm::setHtmlCode,
                        label = { Text("HTML, CSS e JS") },
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 420.dp),
                    )
                    SourceMode.FILE -> FilePicker(
                        hint = "Um único arquivo .html com CSS e JS embutidos.",
                        label = s.sourceLabel,
                        onPick = { pickSource.launch(arrayOf("text/html", "text/plain", "*/*")) },
                    )
                    SourceMode.ZIP -> FilePicker(
                        hint = "Um .zip com index.html na raiz (ou dentro de uma única pasta), mais CSS, JS e imagens.",
                        label = s.sourceLabel,
                        onPick = { pickSource.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*")) },
                    )
                }
            }

            Section("Ícone") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    val preview = s.iconPreview
                    if (preview != null) {
                        Image(
                            bitmap = preview.asImageBitmap(), contentDescription = "Ícone",
                            modifier = Modifier.size(72.dp).clip(RoundedCornerShape(16.dp)),
                        )
                    } else {
                        Text("Ícone padrão", style = MaterialTheme.typography.bodyMedium)
                    }
                    OutlinedButton(onClick = { pickIcon.launch(arrayOf("image/*")) }) { Text("Escolher imagem") }
                    if (preview != null) OutlinedButton(onClick = vm::clearIcon) { Text("Remover") }
                }
            }

            Section("Opções do app") {
                SwitchRow("Tela cheia (esconde barras do sistema)", s.options.fullscreen) {
                    vm.setOptions(s.options.copy(fullscreen = it))
                }
                SwitchRow("Manter a tela ligada", s.options.keepScreenOn) {
                    vm.setOptions(s.options.copy(keepScreenOn = it))
                }
                SwitchRow("Permitir zoom", s.options.allowZoom) {
                    vm.setOptions(s.options.copy(allowZoom = it))
                }
                Text("Orientação", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ScreenOrientation.entries.forEach { o ->
                        FilterChip(
                            selected = s.options.orientation == o,
                            onClick = { vm.setOptions(s.options.copy(orientation = o)) },
                            label = { Text(o.label) },
                        )
                    }
                }
            }

            Button(onClick = vm::build, enabled = !s.building, modifier = Modifier.fillMaxWidth()) {
                if (s.building) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("  Gerando…")
                } else {
                    Text("Gerar APK")
                }
            }

            if (s.log.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Text(
                        s.log.joinToString("\n"), modifier = Modifier.padding(12.dp),
                        style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                    )
                }
            }
            s.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            s.result?.let { file ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("APK gerado: ${file.name}", style = MaterialTheme.typography.titleSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { installApk(context, file) }) { Text("Instalar") }
                            OutlinedButton(onClick = { shareApk(context, file) }) { Text("Compartilhar") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        content()
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun FilePicker(hint: String, label: String?, onPick: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(hint, style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = onPick) { Text(label ?: "Escolher arquivo") }
    }
}

private const val APK_MIME = "application/vnd.android.package-archive"

private fun apkUri(context: Context, file: File): Uri =
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

private fun installApk(context: Context, file: File) {
    if (!context.packageManager.canRequestPackageInstalls()) {
        // O usuário precisa liberar "instalar apps desconhecidos" para o builder; depois toca em Instalar de novo.
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return
    }
    context.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(apkUri(context, file), APK_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
    )
}

private fun shareApk(context: Context, file: File) {
    val send = Intent(Intent.ACTION_SEND)
        .setType(APK_MIME)
        .putExtra(Intent.EXTRA_STREAM, apkUri(context, file))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(send, "Compartilhar APK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
