package com.htmltoapk.shell

import android.content.Context
import org.json.JSONObject

/** Lida de assets/config.json, que o builder grava em cada APK gerado. */
data class ShellConfig(
    val startPath: String = "www/index.html",
    val fullscreen: Boolean = false,
    val keepScreenOn: Boolean = false,
    val allowZoom: Boolean = false,
    val orientation: String = "auto",
) {
    companion object {
        fun load(context: Context): ShellConfig = try {
            val text = context.assets.open("config.json").bufferedReader().use { it.readText() }
            val o = JSONObject(text)
            ShellConfig(
                startPath = o.optString("startPath", "www/index.html"),
                fullscreen = o.optBoolean("fullscreen", false),
                keepScreenOn = o.optBoolean("keepScreenOn", false),
                allowZoom = o.optBoolean("allowZoom", false),
                orientation = o.optString("orientation", "auto"),
            )
        } catch (e: Exception) {
            ShellConfig()
        }
    }
}
